#include "assembler_stage_0.h"

/**
 * the function receives a file name and processes it to create a .am file with the macros expanded
 * @param file_name - the name of the file to process
 * @param my_macro_name_image - a pointer to the macro_name_image structure
 * @return 1 if the file was processed successfully, 0 otherwise
 */
int stage_0_process_file(const char *file_name, macro_name_image *my_macro_name_image) {
    int i, is_inside_macro_flag = FALSE, first_word_in_line_length, macro_body_length = 0, macro_body_allocated_size = MIN_LENGTH_OF_MACRO_BODY, ptr_location, error_flag = FALSE, match_found = FALSE, line_counter = 0;
    macro_array macro_array;
    macro_name *macro_name;
    char macro_header[MAX_LENGTH_OF_MACRO_HEADER], line[MAX_ILLEGAL_LENGTH_OF_LINE];
    char *ptr_in_line, *macro_body, *output_buffer = NULL;
    char *as_version = file_name_extender(file_name, ".as"), *am_version = NULL;
    FILE *as_extension_file = fopen(as_version, "r"), *am_extension_file = NULL;

    if (file_inspector(as_extension_file, as_version)) { /*check if the file is valid*/
        free(as_version);
        return EXIT_FAILURE;
    }
    macro_header[0] = NULL_TERMINATOR,
    macro_body = malloc(MIN_LENGTH_OF_MACRO_BODY);
    if (macro_body == NULL) {
        printf("%s\n", ERROR_FAILED_TO_ALLOCATE_MEM);
        exit(EXIT_FAILURE);
    }
    macro_array_allocator(&macro_array, MIN_LENGTH_OF_MACRO_BODY);

    while (fgets(line, MAX_ILLEGAL_LENGTH_OF_LINE, as_extension_file)) {
        line_counter++;
        ptr_in_line = skip_whitespace(line);
        if(is_end_of_line(ptr_in_line) || *ptr_in_line == SEMI_COLON) /*skip comments and empty lines*/
            continue;
        first_word_in_line_length = first_word_length_counter(ptr_in_line);
        ptr_location = macro_location(ptr_in_line, is_inside_macro_flag, first_word_in_line_length); /*check the type of content is inside the line*/

        if (ptr_location == HEADER) {
            is_inside_macro_flag = TRUE;
            ptr_in_line = skip_to_next_word(ptr_in_line, first_word_in_line_length); /*skip the macro start command*/
            first_word_in_line_length = first_word_length_counter(ptr_in_line);
            strncpy(macro_header, ptr_in_line, first_word_in_line_length);
            ptr_in_line = skip_to_next_word(ptr_in_line, first_word_in_line_length); /*skip the macro name*/
            if (!is_end_of_line(ptr_in_line)) { /*check if there are redundant characters after the macro name set up*/
                error_handler(ERROR_REDUNDANT_CHARACTERS_AFTER_MACRO_NAME, as_version, line_counter);
                error_flag = TRUE;
            }
            macro_header[first_word_in_line_length] = NULL_TERMINATOR;
            if (is_reserved_word(macro_header, first_word_in_line_length)) { /*check if the macro name is a reserved word*/
                error_handler(ERROR_MACRO_NAME_IS_RESERVED_WORD, as_version, line_counter);
                error_flag = TRUE;
            }
            if (is_duplicate_macro_name(&macro_array, macro_header)){ /*check if the macro name already exists*/
                error_handler(ERROR_DUPLICATE_MACRO_NAME, as_version, line_counter);
                error_flag = TRUE;
            }
        } else if (ptr_location == BODY) {
            add_line_to_macro_body(&macro_body, ptr_in_line, &macro_body_length, &macro_body_allocated_size);
        } else if (ptr_location == END) {
            ptr_in_line = skip_to_next_word(ptr_in_line, first_word_in_line_length); /*skip the endmacr command*/
            if (!is_end_of_line(ptr_in_line)) { /*check if there are redundant characters after the endmacr*/
                error_handler(ERROR_REDUNDANT_CHARACTERS_AFTER_ENDMACRO, as_version, line_counter);
                error_flag = TRUE;
                continue;
            }
            macro_array_add(&macro_array, macro_header, macro_body); /*add the macro to the macro array*/
            macro_body_length = 0; /*reset the macro body length*/
            macro_body_allocated_size = MIN_LENGTH_OF_MACRO_BODY; /*reset the macro body length and allocated size*/
            memset(macro_body, NULL_TERMINATOR, macro_body_length);
            is_inside_macro_flag = FALSE;
        } else /* REGULAR */{
            if (error_flag)
                continue;
            for (i = 0; i < macro_array.rep; i++) { /*check if the line is calling a macro and expand it*/
                if (strncmp(ptr_in_line, macro_array.macro_element[i].name, first_word_in_line_length) == 0) {
                    if (is_end_of_line(ptr_in_line + first_word_in_line_length + LENGTH_OF_NULL_TERMINATOR)) {
                        match_found = TRUE;
                        add_to_macro_buffer(&output_buffer, macro_array.macro_element[i].body); /*add the macro body to the output buffer*/
                        break;
                    }
                }
            }
            if (!match_found)
                add_to_macro_buffer(&output_buffer, line); /*if the line is not a macro call, add it to the output buffer*/
            match_found = FALSE; /*reset the match flag*/
        }
    }
    fclose(as_extension_file);
    free(macro_body);
    free(as_version);

    for (i = 0; i < macro_array.rep; i++) { /*add the macro names to the macro name image, to use in later stages*/
        macro_name = new_macro_name(macro_array.macro_element[i].name);
        macro_name_add(my_macro_name_image, macro_name);
    }

    if (!error_flag) {
        am_version = file_name_extender(file_name, ".am");
        am_extension_file = fopen(am_version, "w");
        if (am_extension_file == NULL) {
            printf("%s\n", ERROR_FAILED_TO_OPEN_FILE);
            free(output_buffer);
            macro_array_free(&macro_array);
            return EXIT_SUCCESS;
        }
        free(am_version);
        fputs(output_buffer, am_extension_file);
        fclose(am_extension_file);
    }
    free(output_buffer);
    macro_array_free(&macro_array);
    return error_flag;
}

/**
 * Allocates memory for the macro array and initializes its properties.
 * This function is responsible for initializing a macro array with a given size.
 *
 * @param array - Pointer to the macro_array to allocate memory for.
 * @param size - The initial size of the macro array.
 */
void macro_array_allocator(macro_array *array, const int size) {
    array->macro_element = malloc(size * sizeof(macro));
    if (array->macro_element == NULL) {
        printf("%s\n", ERROR_FAILED_TO_ALLOCATE_MEM);
        exit(EXIT_FAILURE);
    }
    array->rep = 0;
    array->length = size;
}

/**
 * This function checks if a given line is the start of a macro definition (HEADER),
 * part of a macro body (BODY), the end of a macro (END), or a regular line (REGULAR).
 *
 * @param str The string to be analyzed.
 * @param flag An integer flag indicating whether the current processing context is within a macro definition.
 * @param length The length of the first word in the line. This is used to help identify the end of
 *               a macro definition by comparing against the length of the "endmacr" keyword.
 * @return An integer representing the location type of the line.
 */
int macro_location(const char *str, const int flag, const int length) {
    const int COMMAND_LENGTH = strlen("macr");
    if (str && str[COMMAND_LENGTH]) {
        if (str[COMMAND_LENGTH] == SPACE && strncmp(str, "macr", COMMAND_LENGTH) == 0)
            return HEADER;
    }
    if (flag && strncmp(str, "endmacr", length) != 0)
        return BODY;
    if (flag && strncmp(str, "endmacr", length) == 0)
        return END;
    return REGULAR; /* if none of the above, it's a regular line */
}

/**
 * Adds a macro to the macro array, resizing the array size if needed.
 * @param array Macro array to add to.
 * @param name Name of the macro.
 * @param body Content of the macro.
 * @return 0 on success.
 */
int macro_array_add(macro_array *array, const char *name, const char *body) {
    macro *new_array;
    const int number_of_reps = (array->rep); /* number of repetitions */
    int length_of_array = (array->length); /* length of the array */

    if (number_of_reps == length_of_array) {
        length_of_array = length_of_array * 2;
        new_array = realloc(array->macro_element, length_of_array * sizeof(macro));
        if (new_array == NULL) {
            printf("%s\n", ERROR_FAILED_TO_ALLOCATE_MEM);
            exit(EXIT_FAILURE);
        }
        array->macro_element = new_array;
        array->length = length_of_array;
    }

    array->macro_element[number_of_reps].name = malloc(strlen(name) + LENGTH_OF_NULL_TERMINATOR);
    if (array->macro_element[number_of_reps].name == NULL) {
        printf("%s\n", ERROR_FAILED_TO_ALLOCATE_MEM);
        exit(EXIT_FAILURE);
    }
    array->macro_element[number_of_reps].body = malloc(strlen(body) + LENGTH_OF_NULL_TERMINATOR);
    if (array->macro_element[number_of_reps].body == NULL) {
        printf("%s\n", ERROR_FAILED_TO_ALLOCATE_MEM);
        free(array->macro_element[number_of_reps].name);
        exit(EXIT_FAILURE);
    }

    strcpy(array->macro_element[number_of_reps].name, name);
    strcpy(array->macro_element[number_of_reps].body, body);
    array->rep++;
    return EXIT_SUCCESS;
}
/**
 * Frees the memory allocated for the macro array.
 *
 * @param array A pointer to the macro array to be freed.
 */
void macro_array_free(const macro_array *array) {
    int i;
    for (i = 0; i < array->rep; i++) {
        if (array->macro_element[i].name)
            free(array->macro_element[i].name);
        if (array->macro_element[i].body)
            free(array->macro_element[i].body);
    }
    free(array->macro_element);
}

/**
 * Adds a line to the macro body, reallocating memory if necessary.
 *
 * @param macro_body Pointer to the macro body string. This will be reallocated if needed.
 * @param line The line to be added to the macro body.
 * @param current_length Pointer to the current length of the macro body.
 * @param allocated_size Pointer to the allocated size of the macro body.
 */
void add_line_to_macro_body(char **macro_body, const char *line, int *current_length, int *allocated_size) {
    const int line_length = strlen(line);
    char *new_body;

    if (*current_length + line_length + LENGTH_OF_NULL_TERMINATOR > *allocated_size) { /*reallocating the memory if needed*/
        *allocated_size += line_length;
        new_body = realloc(*macro_body, *allocated_size);
        if (new_body == NULL) {
            printf("%s\n", ERROR_FAILED_TO_REALLOC_MEM);
            free(*macro_body);
            exit(EXIT_FAILURE);
        }
        *macro_body = new_body;
    }
    strcpy(*macro_body + *current_length, line); /*adding the line to the macro body*/
    *current_length += line_length; /*updating the current length of the macro body*/
}

/**
 * Appends content to the output buffer.
 *
 * @param buffer Pointer to the output buffer.
 * @param content Content to append to the buffer.
 */
void add_to_macro_buffer(char **buffer, const char *content) {
    int new_size;
    if (*buffer == NULL) { /*allocating memory for the buffer if it's empty*/
        new_size = strlen(content);
        *buffer = malloc(new_size + LENGTH_OF_NULL_TERMINATOR);
        if (*buffer == NULL) {
            printf("%s\n", ERROR_FAILED_TO_ALLOCATE_MEM);
            exit(EXIT_FAILURE);
        }
        strcpy(*buffer, content);
    } else { /* else, reallocating the memory and adding the content to the buffer*/
        new_size = strlen(*buffer) + strlen(content);
        *buffer = realloc(*buffer, new_size + LENGTH_OF_NULL_TERMINATOR);
        if (*buffer == NULL) {
            printf("%s\n", ERROR_FAILED_TO_REALLOC_MEM);
            exit(EXIT_FAILURE);
        }
        strcat(*buffer, content);
    }
}

/**
 * Checks if a given macro name already exists in the macro array.
 *
 * This function iterates through the macro array and compares each macro's name
 * with the provided name. Returns a number based on the match result.
 *
 * @param array A pointer to the macro array to be checked.
 * @param name The name of the macro to check for duplicates.
 * @return 1 if the macro name is a duplicate, 0 otherwise.
 */
int is_duplicate_macro_name(const macro_array *array, const char *name){
    int i;
    for(i = 0; i < array->rep; i++){
        if (strcmp(array->macro_element[i].name, name) == 0)
            return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}