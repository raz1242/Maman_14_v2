#ifndef ASSEMBLER_STAGE_0_H
#define ASSEMBLER_STAGE_0_H

#include "table_utils.h"

#define MAX_LENGTH_OF_MACRO_HEADER 50
#define MIN_LENGTH_OF_MACRO_BODY 1
#define MAX_LENGTH_OF_MACRO_BODY 80
#define AS_FILE_EXTENTION as
#define AM_FILE_EXTENTION am


typedef struct macro_structure{
    char *name;
    char *body;
} macro;

typedef struct macro_array_structure{
    macro *macro_element;
    int rep;
    int length;
} macro_array;

enum pre_stage_line_structure{
    HEADER,
    BODY,
    END,
    REGULAR
};

/* Declarations */
int stage_0_process_file(const char *file_name, macro_name_image *my_macro_name_image);
void macro_array_allocator(macro_array *array, int size);
int macro_location(const char *str, int flag, int length);
int macro_array_add(macro_array *array, const char* name, const char* body);
void macro_array_free(const macro_array *array);
void add_line_to_macro_body(char **macro_body, const char *line, int *current_length, int *allocated_size);
void add_to_macro_buffer(char **buffer, const char *content);
int is_duplicate_macro_name (const macro_array *array, const char *name);

#endif /* ASSEMBLER_STAGE_0_H */